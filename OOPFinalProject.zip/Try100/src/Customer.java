
public class Customer  extends Person{

	public Customer(int ID, String fName, String mName, String lName, String email, String birthday, String address,
			int number, String gender) {
		super(ID, fName, mName, lName, email, birthday, address, number, gender);
		
	}

}
